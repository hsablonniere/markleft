<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Miller columns file browser</title>
  <link rel="stylesheet" href="./index.css">
</head>
<body>
<h1 class="base-directory-name"><?php echo $basePath ?></h1>

<div class="browser-columns">
  <?php
//  foreach ($directories as $directory) {
//    include 'directory.php';
//  }
  ?>
</div>

<script src="./index.js"></script>
</body>
</html>
