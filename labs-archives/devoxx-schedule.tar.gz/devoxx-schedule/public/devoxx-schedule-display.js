dvx.schedule.display = function (schedule) {
  console.log(schedule);
};
