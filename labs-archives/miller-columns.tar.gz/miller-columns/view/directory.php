<ul class="browser-column">
<!--  --><?php //foreach ($directory->getDirectories() as $dir): ?>
<!--  <li class="browser-path browser-directory"><a href="?path=--><?php //echo $dir->getPath() ?><!--">--><?php //echo $dir->getName() ?><!--</a></li>-->
<!--  --><?php //endforeach ?>
<!--  --><?php //foreach ($directory->getFiles() as $file): ?>
<!--  <li class="browser-path browser-file">--><?php //echo $file ?><!--</li>-->
<!--  --><?php //endforeach ?>
</ul>
